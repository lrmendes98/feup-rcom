char* fileName;
int packetSize;
int timeoutSeconds;
int maxTries;
